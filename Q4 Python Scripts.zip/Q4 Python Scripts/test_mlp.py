import numpy as np
import pickle
from P4_Script import predict, Forward_Propagate, sigmoid, softmax
STUDENT_NAME = 'Michael Behr'
STUDENT_ID = '20868195'

class CustomUnpickler(pickle.Unpickler):

    def find_class(self, module, name):
        if name == 'MLP':
            from P4_Script import MLP
            return MLP
        return super().find_class(module, name)


def test_mlp(data_file):
    # Load the test set
    # START
    Data = np.loadtxt(open(data_file, "rb"), delimiter=",")
    # END
    # Load your network
    # START
    
    MLP_Model = CustomUnpickler(open('MLP_Model_Final.pkl', 'rb')).load()
#    with open('MLP_Model_Final.pkl','rb') as input:
#        MLP_Model = pickle.load(input)
    # END


    # Predict test set - one-hot encoded
    y_pred = np.zeros([len(Data),4])
    for i in np.arange(0,len(Data)):
        y_pred[i][predict(MLP_Model, Data[i])] = 1

    
    return y_pred




'''
How we will test your code:

from test_mlp import test_mlp, STUDENT_NAME, STUDENT_ID
from acc_calc import accuracy 

y_pred = test_mlp('./test_data.csv')

test_labels = ...

test_accuracy = accuracy(test_labels, y_pred)*100
'''